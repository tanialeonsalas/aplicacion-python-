# archivo: estudiante.py

class Estudiante:
    def __init__(self, nombre, edad, carrera):
        self.nombre = nombre
        self.edad = edad
        self.carrera = carrera

    def presentarse(self):
        print(f"Hola, me llamo {self.nombre}, tengo {self.edad} años y estudio {self.carrera}.")

    def actualizar_edad(self, nueva_edad):
        if nueva_edad > self.edad:
            self.edad = nueva_edad
            print(f"La edad de {self.nombre} ha sido actualizada a {self.edad} años.")
        else:
            print("La nueva edad debe ser mayor que la actual.")

# Instanciación y uso

if __name__ == "__main__":
    estudiante1 = Estudiante("Carlos", 20, "Ingeniería en Sistemas")
    estudiante2 = Estudiante("Lucía", 22, "Arquitectura")

    estudiante1.presentarse()
    estudiante2.presentarse()

    estudiante1.actualizar_edad(21)
    estudiante1.presentarse()

            
            
